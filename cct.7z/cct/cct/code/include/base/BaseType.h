#ifndef __BASETYPE_H__
#define __BASETYPE_H__

typedef signed char SCHAR;
typedef char CHAR;
typedef unsigned char UCHAR;
typedef signed short SWORD16;
typedef signed long SWORD32;
typedef unsigned short WORD16;
typedef unsigned long WORD32;
typedef unsigned char BOOLEAN;

typedef unsigned char BYTE;
typedef signed short SWORD;
typedef signed long SDWORD;
typedef unsigned short WORD;
typedef unsigned long DWORD;

typedef signed char S8;
typedef unsigned char U8;
typedef signed short S16;
typedef unsigned short U16;
typedef signed long S32;
typedef unsigned long U32;

#ifdef WIN32
typedef unsigned __int64 WORD64;
typedef unsigned __int64 U64;
#else
typedef unsigned long long WORD64;
typedef unsigned long long U64;
#endif

#endif
