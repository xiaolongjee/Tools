#include "gtest/gtest.h"

#include "base/BaseType.h"

struct SampleTest : ::testing::Test
{
	void SetUp()
	{
		value = 1;
	}
protected:
	UCHAR value;
};

TEST_F(SampleTest, should_get_equal_when_value_1)
{
	ASSERT_TRUE(value == 1);
}

TEST_F(SampleTest, should_get_not_equal_when_value_2)
{
	value = 2;

	ASSERT_TRUE(value != 1);
}

TEST(Sample,one_should_equal_one)
{
    ASSERT_TRUE(1,1);
}